package com.qa.Utils;

public class TestUtilClass  {
 public static int PAGE_LOAD_TIMEOUT =60;
 public static int IMPLICIT_WAIT = 60;

}
